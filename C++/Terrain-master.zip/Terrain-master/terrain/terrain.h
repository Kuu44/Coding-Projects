#pragma once
#include<SFML/Graphics.hpp>
#include"vertexarray.h"

struct intersect_data {
	sf::Vector2u range;
	unsigned int pos;
	intersect_data(unsigned int i, unsigned int f, unsigned int po) :pos(po) {
		range.x = i;
		range.y = f;
	}
};
class terrain : public sf::Drawable
{
private:
	sf::Vector2u					window_size;
	sf::Texture				m_texture;
	sf::IntRect						m_textureRect;
	sf::Color						m_fillColor= sf::Color::Blue;
	std::vector<vertexarray>	fills;
	std::vector<vertexarray>	surface;
	std::vector <std::vector <bool>>do_draw;
	sf::VertexArray					m_vertices;
	sf::FloatRect					m_bounds;
	bool							need_update;


	sf::Vector2f computeNormal(const sf::Vector2f& p1, const sf::Vector2f& p2);

	float dotProduct(const sf::Vector2f& p1, const sf::Vector2f& p2);

	sf::FloatRect getbound(std::vector<vertexarray>& fills, sf::Vector2u& window_size);

	unsigned int getlow(std::vector<unsigned int>& input, int max);

	void draw(sf::RenderTarget& target, sf::RenderStates states) const;

	int distance(sf::Vector2f first, sf::Vector2f second);

	void circleintersect(sf::Vector2f position, float radius, std::vector<intersect_data>& list);

public:

	terrain(std::vector<unsigned int>& value, sf::RenderWindow& window, sf::Texture &a);


	void destroy(sf::Vector2f position, float radius);

	std::vector<intersect_data> check_pixels_on_air();

	void test(std::vector<intersect_data>& list);

	bool drop_air_pixel_by_1(std::vector<intersect_data>& list);

	void draw1() ;

	
};



#include "terrain.h"
#include<iostream>

int terrain::distance(sf::Vector2f first, sf::Vector2f second) {
	return sqrt(pow(first.y - second.y, 2) + pow(first.x - second.x, 2));
}

sf::Vector2f terrain::computeNormal(const sf::Vector2f& p1, const sf::Vector2f& p2)
{
	sf::Vector2f normal(p1.y - p2.y, p2.x - p1.x);
	float length = std::sqrt(normal.x * normal.x + normal.y * normal.y);
	if (length != 0.f)
		normal /= length;
	return normal;
}

float terrain::dotProduct(const sf::Vector2f& p1, const sf::Vector2f& p2)
{
	return p1.x * p2.x + p1.y * p2.y;
}


void terrain::draw(sf::RenderTarget &target, sf::RenderStates states) const{

	for (int i = 0; i < window_size.x; i++) {
		states.texture = &m_texture;
		target.draw(fills[i]);
	}

}



sf::FloatRect terrain::getbound(std::vector<vertexarray>& fills, sf::Vector2u& window_size) {
	sf::FloatRect ret(0, 0, window_size.x, 0);

	for (int i = 0; i < fills.size(); i++) {
		if (ret.top < fills[i].getVertexCount())
			ret.top = fills[i].getVertexCount();
	}
	ret.height = window_size.y - ret.top;
	return ret;
}


unsigned int terrain::getlow(std::vector<unsigned int>& input, int max) {

	unsigned int ret = max;
	for (int i = 0; i < input.size(); i++) {
		if (input[i] < ret)
			ret = input[i];
	}
	return ret;
}

terrain::terrain(std::vector<unsigned int>& value, sf::RenderWindow& window, sf::Texture &a) {
	//m_texture = a;

	//m_texture.isRepeated = true;
	window_size = window.getSize();
	fills.resize(window_size.x);
	do_draw.resize(window_size.x);
	int lowest = getlow(value, window_size.y);
	for (int w = 0; w < window_size.x; w++) {
		fills[w].setPrimitiveType(sf::Points);
		fills[w].resize(window_size.y - value[w]);
		do_draw[w].resize(window_size.x - value[w]);
		for (int h = 0; h < window_size.y - value[w]; h++) {
			fills[w][h].position = sf::Vector2f(w, window_size.y - h);
			do_draw[w][h] = true;
			fills[w][h].color = sf::Color(static_cast<float>(255) / (window_size.y - lowest) * h, static_cast<float>(255) / window_size.y * h, static_cast<float>(255) / (window_size.y - lowest) * h, 255);
		}
	}

	m_bounds = getbound(fills, window_size);

}


void terrain::circleintersect(sf::Vector2f position, float radius, std::vector<intersect_data>& list)
{
	for (int x = position.x < radius ? 0 : position.x - radius; x < ((position.x + radius) < window_size.x ? position.x + radius : window_size.x-1); x++) {
		int pos=0;
		bool is_pos_set=false;
		int start=0;
		bool is_start_set=false;
		int i = 0;

		for (int y = 0; y < fills[x].getVertexCount(); y++) {
			if (distance(fills[x][y].position, position) < radius) {
				if (!is_pos_set) {
					pos = x;
					is_pos_set = true;
				}
				if (!is_start_set) {
					start = y;
					is_start_set = true;
				}
				i++;
			}
		}
		if(is_start_set&&is_pos_set)
			list.push_back(intersect_data(start, start + i,pos));
	}
}

void terrain::destroy(sf::Vector2f position, float radius)   //index must have its origin set to center of circle
{
	int a;
	std::vector<intersect_data> list;
	circleintersect(position, radius, list);
	for (int i = 0; i < list.size(); i++) {
		fills[list[i].pos].erase(list[i].range.x, list[i].range.y);
		//std::cout << "value of pos " << list[i].pos << " deleted from " << list[i].range.x << " -- " << list[i].range.y << std::endl;
	}

	need_update = true;
}

std::vector<intersect_data> terrain::check_pixels_on_air() {
	std::vector<intersect_data> list;
	for (int w = 0; w < window_size.x; w++) {
		bool set = false;
		int start=0, end=0;
		int a = fills[w].getVertexCount();
		for (int h = 0; h < a; h++) {
			if (fills[w][h].position.y != (window_size.y - h)) {
				set = true;
				start = h;
				end = fills[w][h].position.y;
				
				break;
			}
		}
		if (set) {
			list.push_back(intersect_data(start, end, w));
			
		}
	}
	return list;
}


bool alldone(std::vector<bool> &test) {
	for (int i = 0; i < test.size(); i++) {
		if (test[i] = false);
		return false;
	}
	return true;
}

void terrain::test(std::vector<intersect_data>& list) {
	for (int i = 0; i < list.size(); i++) {
		for (int j = list[i].range.x; j < fills[list[i].pos].getVertexCount(); j++) {
			fills[list[i].pos][j].color = sf::Color::Green;
		}
	}
}

bool terrain::drop_air_pixel_by_1(std::vector<intersect_data>& list) {

	for (int i = 0; i < list.size(); i++) {
		int w = list[i].pos;

		for (int j = list[i].range.x; j < fills[w].getVertexCount(); j++) {
			fills[w][j].position.y += 1;
			
		}
	}
	return true;
}



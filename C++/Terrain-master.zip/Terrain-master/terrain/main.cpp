#include"terrain.h"
#include<iostream>
#include<array>
#define	PI 3.14159265

const unsigned int width = 1366;
const unsigned int height = 755;


unsigned int getlow(std::vector<unsigned int>& input, int max) {

	unsigned int ret = max;
	for (int i = 0; i < input.size(); i++) {
		if (input[i] < ret)
			ret = input[i];
	}
	return ret;
}
std::vector<unsigned int> get_values(unsigned int gnd_y, unsigned int end_x, unsigned int pixels, unsigned int amplitude) {

	std::vector	<unsigned int> values;
	float increment = (PI / pixels);
	for (int i = 0; i < end_x; i++) {
		values.push_back(gnd_y + amplitude * sin(i * increment));
	}
	return values;
		
}


int main() {

	sf::RenderWindow window(sf::VideoMode(width, height), "title");
	sf::Event event;
	sf::VertexArray	surface;
	surface.resize(width);
	std::vector	<unsigned int>	values;
	values.reserve(width);
	values = get_values(200, width, 100, 100);
	sf::Texture a;
	a.loadFromFile("../text.png");
	terrain t(values,window,a);


	for (int i = 1; i < values.size(); i++) {
		surface[i].position = sf::Vector2f(i, values[i]);

	}

	

	while (window.isOpen()) {
		while (window.pollEvent(event)) {
			switch (event.type)
			{
			case sf::Event::Closed:
				window.close();
				break;
			case  sf::Event::MouseButtonPressed:
				sf::Vector2f pos(event.mouseButton.x, event.mouseButton.y);
				std::cout << "mouse postion" << pos.x << "    " << pos.y << std::endl;
				//std::cout << "distance is " << t.distance(sf::Vector2f(500, 500), pos) << std::endl;
				t.destroy(pos, 50);
				
				if (!t.check_pixels_on_air().empty()) {
					auto a = t.check_pixels_on_air();
					/*t.test(a);
					window.clear();
					window.draw(t);
					window.display();*/

					bool done = a.empty();
					while (!done) {
						a = t.check_pixels_on_air();
						if (a.empty())
							done = true;
						t.drop_air_pixel_by_1(a);
						window.clear();
						window.draw(t);
						window.display();

					}
				}
				break;

			}
		}
		window.clear();
		window.draw(surface);
		window.draw(t);
		window.display();
	}

	return 0;

}
# Terrain
Implementation of Destructible terrain as of game pocket tanks.


Please copy libs folder to deps/SFML.  (same folder with "include" folder).

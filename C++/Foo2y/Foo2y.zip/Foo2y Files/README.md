# Foo2y
A 2D Football game for a C++ Assignment

# About
It's a 2-player game currently, with 2 players facing each other in a game of football

# Controls
## Player 1: 
          Movement:      W,A,S,D
          Change player: C
          Pass/Sprint:   V 
          Shoot/Tackle:  X
          
## Player 2: 
          Movement:      Up,Down,Left,Right
          Change player: M
          Pass/Sprint:   < 
          Shoot/Tackle:  N

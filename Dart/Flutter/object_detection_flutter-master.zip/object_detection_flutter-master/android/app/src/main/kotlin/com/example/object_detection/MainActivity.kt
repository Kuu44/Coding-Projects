package com.example.object_detection

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import javax.swing.ImageIcon;

/**
 * Program file : Assignment 2: GUI JAVA Application � Baby Ball Bounce
 * Filename: Bricks.java
 * @author: � Joyal Joshi UoN (20416225)
 * Course: BSc(hons)Computing Year 1
 * Module:Problem Solving & Programming (PSP) | CSY1020 
 * Module Tutor from UoN:: Scott Turner
 * Module Tutor from NAMI: Kumar Lamichhane
 * Date: 22nd September 2020
 */

@SuppressWarnings("serial")
public class Bricks extends Actor {

	public Bricks(ImageIcon icon) {
		super(icon);
	}

	
	@Override
	public void act() {
	}

}
